package SupportLibraries;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;



/**
 * Driver script class which encapsulates the core logic of the framework
 * @author Cognizant
 */
public class DriverScript
{
	
	
	BaseTest basetest = new BaseTest();
	private WebDriver driver;
	private Properties properties;
	private ExecutionMode executionMode;
	private String testStatus;
	private final SeleniumTestParameters testParameters;
	private ScriptHelper scriptHelper;
	
	
	
	/**
	 * Function to get the status of the test case executed
	 * @return The test status
	 */
 	public String getTestStatus()
	{
		return testStatus;
	}
	
	/**
	 * Constructor to initialize the DriverScript
	 */
	public DriverScript(SeleniumTestParameters testParameters)
	{
		this.testParameters = testParameters;
	}
	
	private void initializeTestScript()
	{
		scriptHelper = new ScriptHelper(driver);
		
		basetest.initialize(scriptHelper);
	}
	
	/**
	 * Function to execute the given test case
	 */
	public void driveTestExecution()
	{
		createReportBackUPForReportHistory();
		createReportBackUPForHtmlReport();
		startUp();
		enableProtectedMode();
		initializeWebDriver();
		initializeTestScript();
		
	}
	
	private void startUp()
	{
	
		properties = Settings.getInstance();
		testParameters.setBrowser(Browser.valueOf(properties.getProperty("DefaultBrowser")));
	
	}

	public void enableProtectedMode()
	{
		String ieEnable = "./AutoIT/EnableProtectedMode.exe";
		try {
			Runtime.getRuntime().exec(ieEnable);
		}
		catch(Throwable t) { t.printStackTrace(); }
	}    

	private void initializeWebDriver()
	{
		executionMode = ExecutionMode.valueOf(properties.getProperty("ExecutionMode"));
		
		switch(executionMode) {
		case Local:
			driver = WebDriverFactory.getDriver(testParameters.getBrowser());
			break;
			
		case Remote:
			driver = WebDriverFactory.getDriver(testParameters.getBrowser(),
													properties.getProperty("RemoteUrl"));
			break;
			
		case Grid:
			driver = WebDriverFactory.getDriver(testParameters.getBrowser(),
													testParameters.getBrowserVersion(),
													testParameters.getPlatform(),
													properties.getProperty("RemoteUrl"));
			break;
			
		default:
			throw new FrameworkException("Unhandled Execution Mode!");
		}
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public  BaseTest getBaseTest()
	{
		return basetest;
	}
	
	
	/*
	 * Method to take the report back up for test ng execution report files
	 */
	private void createReportBackUPForReportHistory()
	{
		DateFormat df = new SimpleDateFormat("MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		String monthAndYear = df.format(cal.getTime());
		
		
		File file = new File("./TestNGReportHistory/" +monthAndYear);
		if(!file.exists())
		file.mkdir();
		
		
		df = new SimpleDateFormat("dd");
		String date = df.format(cal.getTime());
		
		file = new File("./TestNGReportHistory/" +monthAndYear+"/"+date);
		if(!file.exists())
		file.mkdir();
		
		
		df = new SimpleDateFormat("HH-mm-ss");
		String time = df.format(cal.getTime());
		time.replaceAll(":", "_");
		file = new File("./TestNGReportHistory/" +monthAndYear+"/"+"/"+date+"/"+time);
		file.mkdir();
		
		File srcFile = new File("./test-output");
		
		try 
		{
			FileUtils.copyDirectoryToDirectory(srcFile, file);
			FileUtils.cleanDirectory(srcFile);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	/*
	 * Method to take the report back up for Html execution report files
	 */
	private void createReportBackUPForHtmlReport()
	{
		DateFormat df = new SimpleDateFormat("MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		String monthAndYear = df.format(cal.getTime());
		
		
		File file = new File("./HtmlReportHistory/" +monthAndYear);
		if(!file.exists())
		file.mkdir();
		
		
		df = new SimpleDateFormat("dd");
		String date = df.format(cal.getTime());
		
		file = new File("./HtmlReportHistory/" +monthAndYear+"/"+date);
		if(!file.exists())
		file.mkdir();
		
		
		df = new SimpleDateFormat("HH-mm-ss");
		String time = df.format(cal.getTime());
		time.replaceAll(":", "_");
		file = new File("./HtmlReportHistory/" +monthAndYear+"/"+"/"+date+"/"+time);
		file.mkdir();
		
		File srcFile = new File("./HtmlReport");
		
		try 
		{
			FileUtils.copyDirectoryToDirectory(srcFile, file);
			FileUtils.cleanDirectory(srcFile);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
		
		/*
		 * Method to take the Customized Smoke Report Back Up
		 */
		public static void createSmokeReportBackUP()
		{
			DateFormat df = new SimpleDateFormat("MMM-yyyy");
			Calendar cal = Calendar.getInstance();
			String monthAndYear = df.format(cal.getTime());
			
			
			File file = new File("//ho/dfs03/cts_automation/00_Selenium/NMC/DashboardTest/ReportBackup/" +monthAndYear);
			if(!file.exists())
			file.mkdir();
			
			
			df = new SimpleDateFormat("dd");
			String date = df.format(cal.getTime());
			System.out.println(monthAndYear);
			
			file = new File("//ho/dfs03/cts_automation/00_Selenium/NMC/DashboardTest/ReportBackup/" +monthAndYear+"/"+date);
			if(!file.exists())
			file.mkdir();
			
			
			df = new SimpleDateFormat("HH-mm-ss");
			String time = df.format(cal.getTime());
			time.replaceAll(":", "_");
			file = new File("//ho/dfs03/cts_automation/00_Selenium/NMC/DashboardTest/ReportBackup/" +monthAndYear+"/"+"/"+date+"/"+time);
			file.mkdir();
			
			File srcFile = new File("//ho/dfs03/cts_automation/00_Selenium/NMC/DashboardTest/HtmlReport");
			File src     = new File("//ho/dfs03/cts_automation/00_Selenium/NMC/DashboardTest/HtmlReport/SmokeTestResult.html");
			try 
			{
				if(src.exists())
				FileUtils.copyDirectoryToDirectory(srcFile, file);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
			
		
	
	}

}