package Pages.MI.HYCS;

import java.util.List;
import SupportLibraries.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;
import org.openqa.selenium.support.ui.Select;

public class HYCSAddComments extends MasterPage {
	
	
	By lblHomePageHeader	= By.xpath("/html/body/div[1]/section/div[1]/div/h2");
	By tabsHomePage 		= By.xpath("//ul[@class='nav navbar-nav']/li");
	
	By tabHome				= By.xpath("//ul[@class='nav navbar-nav']/li[1]/a");
	By tabComments			= By.xpath("//ul[@class='nav navbar-nav']/li[2]/a");
	By tabUploads			= By.xpath("//ul[@class='nav navbar-nav']/li[3]/a");
	By tabMaintenance		= By.xpath("//ul[@class='nav navbar-nav']/li[4]/a");
	By tabFundamentals		= By.xpath("//ul[@class='nav navbar-nav']/li[5]/a");
	By tabIssueEditor		= By.xpath("//ul[@class='nav navbar-nav']/li[6]/a");
	By tabTextConverter		= By.xpath("//ul[@class='nav navbar-nav']/li[7]/a");
	By tabReporting			= By.xpath("//ul[@class='nav navbar-nav']/li[8]/a");
	By tabEPS				= By.id("navEmail");
	
	By tblLinks				= By.xpath("//div[@id='accordion']/div");
	By lnkComments			= By.xpath("//div[@id='accordion']/div[1]/div[1]/h4/a");
	By lnkUploads			= By.xpath("//div[@id='accordion']/div[2]/div[1]/h4/a");
	By lnkMaintenance		= By.xpath("//div[@id='accordion']/div[3]/div[1]/h4/a");
	By lnkFundamentals		= By.xpath("//div[@id='accordion']/div[4]/div[1]/h4/a");
	By lnkIssueEditor		= By.xpath("//div[@id='accordion']/div[5]/div[1]/h4/a");
	By lnkTextConverter		= By.xpath("//div[@id='accordion']/div[6]/div[1]/h4/a");
	By lnkReporting			= By.xpath("//div[@id='accordion']/div[7]/div[1]/h4/a");
	By lnkTickersnComp		= By.xpath("//*[@id='myNavbar']/ul[1]/li[2]/ul/li[1]/a");
	
	
	By lblFundamentalsHdr 	= By.xpath("//div[@class='container-fluid']/h2");
	By txtParentIssuer 		= By.id("ParentIssuerInput");
	By btnRetrieve 			= By.id("RetrieveBtn");
	By drpdnMinorIndustry	= By.name("MinorIndustry");
	//By btnAddComment        = By.id("addButton"); 
	By btnAddComment        = By.xpath("//button[@id='addButton']"); 
    By txtAreaComment       = By.xpath("//div[@class='modal-body']/div[2]/textarea");
    By btnSubmitComment     = By.xpath("//div[@class='modal-footer']/button"); 
    By btnRemoveComment     = By.xpath("//div[@class='btn btn-warning btn-secondary btn-sm']");
    By btnRemoveComment1    = By.xpath("/html/body/div[1]/section/div[2]/div[3]/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/form/button");
    By results 				= By.xpath("//div[@id='idquarterheader']/div[*]");
    By btnSubmitRevenueChange = By.xpath("//button[@id='submitFormData']");
    By nbrIncomeStatementRevenue7 = By.id("IncomeStatementRevenue7");
     
	
	public HYCSAddComments(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	
	
	/**
	 * Method to Verify the comments Page.
	 */
	
	public HYCSAddComments verifyCommentsPage(String testCase) throws Exception {
		try {
			
			driver.findElement(By.linkText("Comments")).click();
			driver.findElement(By.linkText("Daily Rolling Comments")).click();
			Select dropdownMinorIndustry = new Select(driver.findElement(By.id("IndustryDropDown"))); 
			dropdownMinorIndustry.selectByVisibleText("AUTOMOTIVE"); 
			Select dropdownEquityTicker = new Select(driver.findElement(By.id("EquityTickerDropdown"))); 
			dropdownEquityTicker.selectByVisibleText("ABC US");
			isElementClickable(getElement(btnAddComment)); 
			clickUsingJavaScript(getElement(btnAddComment)); 
			
			System.out.println("Comments = " + dataLoader.getTestdata("HYCSTestData", testCase,"Comments"));
			driver.findElement(txtAreaComment).sendKeys(dataLoader.getTestdata("HYCSTestData", testCase,"Comments")); 
						
			} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to verify the Comments Page");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
	public HYCSAddComments deleteComment() throws Exception {
		try {
			Thread.sleep(5000);
			
			List<WebElement> listRemoveBtns = driver.findElements(By.xpath("//button[contains(.,'Remove')]"));//className("btn btn-warning btn-secondary btn-sm"));
			int i = 0;
			System.out.println("listRemoveBtns.size() = " + listRemoveBtns.size());
			i = listRemoveBtns.size() - 1;
			System.out.println("i = " + i);
			listRemoveBtns.get(i).sendKeys(Keys.RETURN);
			isElementClickable(getElement(btnRemoveComment1)); 
			clickUsingJavaScript(getElement(btnRemoveComment1));
			Thread.sleep(3000);
							
			} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to delete the Comment.");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}



	public HYCSAddComments verifyRevenueChange(String testCase) throws Exception {
		try {
			
			isElementClickable(getElement(tabHome));
			clickUsingJavaScript(getElement(tabHome));
			
			driver.findElement(By.linkText("Fundamental Editors")).click();
			driver.findElement(lnkFundamentals).click();
						
			isElementDisplayed(lblFundamentalsHdr);
			Assert.assertEquals(getElement(lblFundamentalsHdr).getText(), dataLoader.getTestdata("HYCSTestData", testCase,"Fundamentals Page Header"), "HYCS Fundamentals Page - Header Name Mismatch");
			
			Assert.assertEquals(getElement(txtParentIssuer).getAttribute("value").isEmpty(), true, "HYCS Fundamentals Page - Before Selecting Minor Industry : Parent Issuer Field is not empty");
			Assert.assertEquals(getElement(btnRetrieve).isEnabled(), false, "HYCS Fundamentals Page - Before Selecting Minor Industry : Retrieve Button is enabled");
			
			selectFromDropdown(drpdnMinorIndustry, dataLoader.getTestdata("HYCSTestData", testCase,"Minor Industry"));
			
			isElementClickable(getElement(btnRetrieve));
			
			Assert.assertEquals(getElement(txtParentIssuer).getAttribute("value").isEmpty(), false, "HYCS Fundamentals Page - After Selecting Minor Industry : Parent Issuer Field is empty");
			Assert.assertEquals(getElement(btnRetrieve).isEnabled(), true, "HYCS Fundamentals Page - After Selecting Minor Industry : Retrieve Button is not enabled");
			
			clickUsingJavaScript(getElement(btnRetrieve));
			
			getWebelementsPesent(results,45);
			
			List<WebElement> listResults = driver.findElements(results);
			boolean resultsSize = listResults.size() > 0;
			Assert.assertEquals(resultsSize, true, "HYCS Fundamentals Page - After Selecting Minor Industry : Results not available");
			driver.findElement(nbrIncomeStatementRevenue7).clear();
			driver.findElement(nbrIncomeStatementRevenue7).sendKeys(dataLoader.getTestdata("HYCSTestData", testCase,"Revenue"));
			isElementClickable(getElement(btnSubmitRevenueChange)); 
			clickUsingJavaScript(getElement(btnSubmitRevenueChange)); 
			System.out.println("clicked on submit");
			} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to verify the Revenue Change Page");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
	
}