package Pages.MI.HYCS;

import java.util.List;

//import org.apache.jasper.tagplugins.jstl.core.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;
import org.openqa.selenium.support.ui.Select;

public class HYCSHomePage extends MasterPage {
	
	By lblHomePageHeader	= By.xpath("/html/body/div[1]/section/div[1]/div/h2");
	By tabsHomePage 		= By.xpath("//ul[@class='nav navbar-nav']/li");
	
	
	By tabHome				= By.xpath("//ul[@class='nav navbar-nav']/li[1]/a");
	By tabComments			= By.xpath("//ul[@class='nav navbar-nav']/li[2]/a");
	By tabUploads			= By.xpath("//ul[@class='nav navbar-nav']/li[3]/a");
	By tabMaintenance		= By.xpath("//ul[@class='nav navbar-nav']/li[4]/a");
	By tabFundamentals		= By.xpath("//ul[@class='nav navbar-nav']/li[5]/a");
	By tabIssueEditor		= By.xpath("//ul[@class='nav navbar-nav']/li[6]/a");
	By tabTextConverter		= By.xpath("//ul[@class='nav navbar-nav']/li[7]/a");
	By tabReporting			= By.xpath("//ul[@class='nav navbar-nav']/li[8]/a");
	By tabEPS				= By.id("navEmail");
	
	By tblLinks				= By.xpath("//div[@id='accordion']/div");
	
	
	By lnkComments			= By.xpath("//div[@id='accordion']/div[1]/div[1]/h4/a");
	By lnkUploads			= By.xpath("//div[@id='accordion']/div[2]/div[1]/h4/a");
	By lnkMaintenance		= By.xpath("//div[@id='accordion']/div[3]/div[1]/h4/a");
	By lnkFundamentals		= By.xpath("//div[@id='accordion']/div[4]/div[1]/h4/a");
	By lnkIssueEditor		= By.xpath("//div[@id='accordion']/div[5]/div[1]/h4/a");
	By lnkTextConverter		= By.xpath("//div[@id='accordion']/div[6]/div[1]/h4/a");
	By lnkReporting			= By.xpath("//div[@id='accordion']/div[7]/div[1]/h4/a");
	By lnkTickersnComp		= By.xpath("//*[@id='myNavbar']/ul[1]/li[2]/ul/li[1]/a");
	
	
//	By lnkFundamentals 		= By.xpath("//*[@id='navQuarterlyFundamentalsMain']");
	//By lblFundamentalsHdr 	= By.xpath("//div[@class='container-fluid']/h2");
	By lblFundamentalsHdr 	= By.xpath("/html/body/div[1]/section/div/div[5]/h2");
	
	By txtParentIssuer 		= By.id("ParentIssuerInput");
	By btnRetrieve 			= By.id("RetrieveBtn");
	By drpdnMinorIndustry	= By.name("MinorIndustry");
	By btnAddComment        = By.id("addButton"); 
    By txtAreaComment       = By.id("comment-646-text"); 
    By results 				= By.xpath("//div[@id='idquarterheader']/div[*]");
    By btnSubmitRevenueChange = By.id("submitFormDataAlternate");
    By nbrIncomeStatementRevenue7 = By.id("IncomeStatementRevenue7");
     
	
	public HYCSHomePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	/**
	 * Method to Verify the Home Page Fields
	 */
	
	public HYCSHomePage verifyHYCSHomePage(String testCase) throws Exception {
		try {
			
			isElementDisplayed(lblHomePageHeader);
			Assert.assertEquals(getElement(lblHomePageHeader).getText(), dataLoader.getTestdata("HYCSTestData", testCase,"Home Page Header"), "HYCS Home Page - Header Name Mismatch");
		
			List<WebElement> listTabLinks = driver.findElements(tabsHomePage);
			boolean tabLinksSize = listTabLinks.size() > 0;
			Assert.assertEquals(tabLinksSize, true, "HYCS Home Page - Top Header tabs not available");
			
			if(tabLinksSize) {
				Assert.assertEquals(getElement(tabHome).getText(), "Home", "HYCS Home Page - Tab : Home Label Name Mismatch");
				Assert.assertEquals(getElement(tabComments).getText(), "Comments", "HYCS Home Page - Tab : Comments Label Name Mismatch");
				Assert.assertEquals(getElement(tabUploads).getText(), "Uploads", "HYCS Home Page - Tab : Uploads Label Name Mismatch");
				Assert.assertEquals(getElement(tabMaintenance).getText(), "Maintenance", "HYCS Home Page - Tab : Maintenance Label Name Mismatch");
				Assert.assertEquals(getElement(tabFundamentals).getText(), "Fundamental Editors", "HYCS Home Page - Tab : Fundamentals Label Name Mismatch");
				Assert.assertEquals(getElement(tabIssueEditor).getText(), "New Issue Editor", "HYCS Home Page - Tab : New Issue Editor Label Name Mismatch");
				Assert.assertEquals(getElement(tabTextConverter).getText(), "Bloomberg Text Converter", "HYCS Home Page - Tab : Bloomberg Text Converter Label Name Mismatch");
				Assert.assertEquals(getElement(tabReporting).getText(), "Reporting", "HYCS Home Page - Tab : Reporting Label Name Mismatch");
				Assert.assertEquals(getElement(tabEPS).getText(), "  EPS", "HYCS Home Page - Tab : EPS Label Name Mismatch");
			}
			
			List<WebElement> listLinks = driver.findElements(tblLinks);
			boolean tblLinksSize = listLinks.size() > 0;
			Assert.assertEquals(tblLinksSize, true, "HYCS Home Page - Links not available");
			
			if(tblLinksSize) {
				Assert.assertEquals(getElement(lnkComments).getText(), "Comments", "HYCS Home Page - Link : Comments Label Name Mismatch");
				Assert.assertEquals(getElement(lnkUploads).getText(), "Uploads", "HYCS Home Page - Link : Uploads Label Name Mismatch");
				Assert.assertEquals(getElement(lnkMaintenance).getText(), "Maintenance", "HYCS Home Page - Link : Maintenance Label Name Mismatch");
				Assert.assertEquals(getElement(lnkFundamentals).getText(), "Fundamentals", "HYCS Home Page - Link : Fundamentals Label Name Mismatch");
				Assert.assertEquals(getElement(lnkIssueEditor).getText(), "New Issue Editor", "HYCS Home Page - Link : New Issue Editor Label Name Mismatch");
				Assert.assertEquals(getElement(lnkTextConverter).getText(), "Bloomberg Text Converter", "HYCS Home Page - Link : Bloomberg Text Converter Label Name Mismatch");
				Assert.assertEquals(getElement(lnkReporting).getText(), "Reporting", "HYCS Home Page - Link : Reporting Label Name Mismatch");
			}
			
		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to verify the Home Page");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
		
	/**
	 * Method to Verify the Fundamentals Link Page Fields
	 */
	
	public HYCSHomePage verifyFundamentalsPage(String testCase) throws Exception {
		try {
			driver.findElement(By.linkText("Fundamental Editors")).click();
			driver.findElement(By.linkText("Fundamentals")).click();
						
			isElementDisplayed(lblFundamentalsHdr);
			Assert.assertEquals(getElement(lblFundamentalsHdr).getText(), dataLoader.getTestdata("HYCSTestData", testCase,"Fundamentals Page Header"), "HYCS Fundamentals Page - Header Name Mismatch");
			
			Assert.assertEquals(getElement(txtParentIssuer).getAttribute("value").isEmpty(), true, "HYCS Fundamentals Page - Before Selecting Minor Industry : Parent Issuer Field is not empty");
			Assert.assertEquals(getElement(btnRetrieve).isEnabled(), false, "HYCS Fundamentals Page - Before Selecting Minor Industry : Retrieve Button is enabled");
			
			selectFromDropdown(drpdnMinorIndustry, dataLoader.getTestdata("HYCSTestData", testCase,"Minor Industry"));
			
			isElementClickable(getElement(btnRetrieve));
			
			Assert.assertEquals(getElement(txtParentIssuer).getAttribute("value").isEmpty(), false, "HYCS Fundamentals Page - After Selecting Minor Industry : Parent Issuer Field is empty");
			Assert.assertEquals(getElement(btnRetrieve).isEnabled(), true, "HYCS Fundamentals Page - After Selecting Minor Industry : Retrieve Button is not enabled");
			
			clickUsingJavaScript(getElement(btnRetrieve));
			
			getWebelementsPesent(results,45);
			
			List<WebElement> listResults = driver.findElements(results);
			boolean resultsSize = listResults.size() > 0;
			Assert.assertEquals(resultsSize, true, "HYCS Fundamentals Page - After Selecting Minor Industry : Results not available");
						
		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to verify the Fundamentals Page");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}

}