package TestScripts.TechUpgrade.MI.HYCS;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Common.SSOPage;
import Pages.MI.HYCS.HYCSCSSPage;
import Pages.MI.HYCS.HYCSHomePage;
import Pages.MI.HYCS.HYCSAddComments;
import SupportLibraries.BaseTest;
import SupportLibraries.ListenerClass;

public class HYCSTest extends BaseTest
{
	@BeforeClass
	public void intialize()
	{
		ssoPage			= new SSOPage(driverScript.getBaseTest().getScriptHelper());
		HYCSCssPage		= new HYCSCSSPage(driverScript.getBaseTest().getScriptHelper());
		HYCSHomePage	= new HYCSHomePage(driverScript.getBaseTest().getScriptHelper());
		HYCSAddComments	= new HYCSAddComments(driverScript.getBaseTest().getScriptHelper());
	}
	
	/**
	 * SSO_login : 'Logging into the SSO'
	 */
	
	@Test
	public void SSO_login() {
		try {
			
			ssoPage.getSSOApplication();
			ssoPage.typeUserName("TC_SSO_Login");
			ssoPage.typePassword("TC_SSO_Login");
			ssoPage.clicksignonButton();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_launch : 'Launching the Application'
	 */
	
	@Test( dependsOnMethods = {"SSO_login"} )
	public void TC_HYCS_launch() {
		try {
			HYCSCssPage.getHYCSApplication();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_01_homePage : 'Validation of Home Page Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_launch"} )
	public void TC_HYCS_01_homePage() {
		try {
			HYCSHomePage.verifyHYCSHomePage("TC_HYCS_01");
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_02_fundamentalsLinkPage : 'Validation of Fundamentals Link Page Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_01_homePage"} )
	public void TC_HYCS_02_fundamentalsLinkPage() {
		try {
			HYCSHomePage.verifyFundamentalsPage("TC_HYCS_02");
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_03_commentsLinkPage : 'Validation of Comments Link Page Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_01_homePage"} )
	public void TC_HYCS_03_CommentsLinkPage() {
		try {
			HYCSAddComments.verifyCommentsPage("TC_HYCS_03");
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_03_commentsLinkPage : 'Delete Comment Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_01_homePage"} )
	public void TC_HYCS_DeleteComments() {
		try {
			HYCSAddComments.deleteComment();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_04_RevenueChangePage : 'Validation of Revenue Change Page Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_01_homePage"} )
	public void TC_HYCS_04_RevenueChangePage() {
		try {
			HYCSAddComments.verifyRevenueChange("TC_HYCS_04");
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 *  SSO_signOff : 'Validate user able to Sign Off'
	 */
	
	@Test(dependsOnMethods = { "TC_HYCS_02_fundamentalsLinkPage" })
	public void SSO_signOff() {
		try {
			ssoPage.clickSignOffButton();
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
}