package SupportLibraries;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


/**
 * Email class implements Emailing feature .Uses Java Mail to send mail using the SMTP server. 
 * The user need to raise an Exchange connection request to send email
 * @author Cognizant
 * 
 *
 */
public class Email {

	/**
	 * Method triggers an email Using the SMTP server 
	 * @param recipientList
	 * @param ccList
	 * @param subject
	 */
	public static void sendMail(String recipientList, String ccList,
			String subject) {
		int count              = 0;
		String[] to            = recipientList.split(";");
		String[] cC            = ccList.split(";");
		String from            = Settings.getInstance() != null ? (Settings.getInstance()).getProperty("mailSender") : null;
		String host            = "exapps.nml.com";
		Properties prop        = System.getProperties();
		String emailAttachment = Settings.getInstance() != null ? (Settings.getInstance()).getProperty("mailAttachment") : null;
		
		
		
		prop.put("mail.smtp.auth", "false");
		prop.put("mail.smtp.starttls.enabled", "true");
		prop.setProperty("mail.smtp.host", host);
		prop.setProperty("mail.smtp.port", "25");
		Session session = Session.getDefaultInstance(prop);
		
		try {
			// generating multiple recipients
			InternetAddress[] recipientAddress = new InternetAddress[to.length];
			InternetAddress[] cCAddress = new InternetAddress[cC.length];
			for (String address : to) {
				recipientAddress[count] = new InternetAddress(address.trim());
				count++;
			}
			count = 0;
			for (String address : cC) {
				cCAddress[count] = new InternetAddress(address.trim());
				count++;
			}

			// Body
			MimeMessage message = new MimeMessage(session);
			String donotReply = "************************  This is An Auto Generated Mail    *******************************";
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, recipientAddress);
			message.setRecipients(Message.RecipientType.CC, cCAddress);
			message.setSubject(subject);
			message.setHeader("X-Priority", "1");
			BodyPart body = new MimeBodyPart();
			body.setText("Specify the body content");
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(body);
			body = new MimeBodyPart();
			DataSource source = new FileDataSource(emailAttachment);
			body.setDataHandler(new DataHandler(source));
			multipart.addBodyPart(body);
			message.setContent(multipart);
			Transport.send(message);

		} catch (MessagingException m) {
			m.printStackTrace();
		}

		catch (NullPointerException m) {
			m.printStackTrace();
		}

	}

}
				
	


