package SupportLibraries;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

/**
 * 
 * Data loader defines all the methods required for Loading the data from data sheets in to collection objects
 * 
 * @author Cognizant
 *
 */

public class DataLoader {

	// For HYCS - High Yield Comp Sheets
	private static Hashtable<String, Hashtable<String, String>> HYCSTestData;
	
	private static Hashtable<String, Hashtable<String, String>> Purpose;
		
	/**
	 * The {@link Properties} object with settings loaded from the framework properties file
	 */
	protected Properties properties;
	
	
	/**
	 * Default constructor
	 */

	public DataLoader() {
		
	}
	
	/**
	 * Method to load data from data work books to collections objects(Hash
	 * Table)
	 */
	public void LoadDatatables() {
		
		// For HYCS - High Yield Comp Sheets
		HYCSTestData	= loadDataTable("HYCSData","HYCS");
		Purpose 		= loadDataTable("HYCSData","Testcasepurpose");
	}
	
	/**
	 * 
	 * method to load data from log in workbook to collection object
	 */
	
	private Hashtable<String, Hashtable<String, String>> loadDataTable(
			String workBookName, String sheetName) {
		int rowCount;
		int columnCount;
		properties = Settings.getInstance();
		
		Hashtable<String, String> temp = null;
		Hashtable<String, Hashtable<String, String>> tempDataTable = new Hashtable<String, Hashtable<String, String>>();
		try {
			HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(
					".\\Datatables\\" + properties.getProperty("ApplicationEnvironment") + "\\" + ListenerClass.strBusinessArea + "\\" + workBookName + ".xls"));
			HSSFSheet sheet = workbook.getSheet(sheetName);
			rowCount = sheet.getLastRowNum() + 1;
			columnCount = sheet.getRow(0).getLastCellNum();
			for (int i = 1; i < rowCount; i++) {
				temp = new Hashtable<String, String>();
				for (int j = 1; j < columnCount; j++) {
					try {

						Cell cell = sheet.getRow(i).getCell(j);
						String value = "";
						if (cell.getCellType() != HSSFCell.CELL_TYPE_BLANK) {

							switch (cell.getCellType()) {
							case HSSFCell.CELL_TYPE_NUMERIC:
								value = BigDecimal.valueOf(
										cell.getNumericCellValue())
										.toPlainString();
								break;

							case HSSFCell.CELL_TYPE_STRING:
								value = cell.getStringCellValue();
								break;

							case HSSFCell.CELL_TYPE_FORMULA:
								value = cell.getCellFormula();
								break;

							default:
								break;
							}
						}
						
						temp.put(sheet.getRow(0).getCell(j).toString(), value);
					} catch (NullPointerException e) {

					}

				}

				if (sheetName.equalsIgnoreCase("TC2DataMap"))
					tempDataTable.put(sheet.getRow(i).getCell(0).toString()
							+ sheet.getRow(i).getCell(1).toString(), temp);
				else
					tempDataTable.put(sheet.getRow(i).getCell(0).toString(),
							temp);

			}
			return tempDataTable;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * The method returns the data based on the data set and Data container name,and ColumnName
	 * 
	 * 
	 * 
	 * @param dataContainerName
	 * @param dataSet
	 * @param columnName
	 * @return test data in String format
	 */
	public String getTestdata(String dataContainerName, String dataSet,
			String columnName) {
		Hashtable<String, Hashtable<String, String>> dataTable = null;
		try {
			// HYCS - High Yield Comp Sheets
			if(dataContainerName.equals("HYCSTestData"))
				dataTable = HYCSTestData;
			if(dataContainerName.equals("Purpose"))
				dataTable = Purpose;
		}
		catch (Exception e) {
			return "DataNotAvaialable";
		}
		return dataTable.get(dataSet).get(columnName);
	}

}
