package Pages.MI.HYCS;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class HYCSCSSPage extends MasterPage {

	public HYCSCSSPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	/**
	 * Method to launch the HYCS Application URL
	 */

	public HYCSCSSPage getHYCSApplication() throws Exception {
		try {
			driver.manage().window().maximize();
			waitTill(3000);
			driver.get(properties.getProperty("HYCSApplicationURL"));
			waitTill(3000);
		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to launch the application using " + properties.getProperty("HYCSApplicationURL"));
				throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
}