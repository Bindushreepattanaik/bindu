package Pages.Common;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;
import Utils.StringEncrypt;

public class SSOPage  extends MasterPage{

	By userNameTextBox    = By.name("USER");
	By passwordTextBox    = By.name("PASSWORD");
	
	By signoffBtn				= By.cssSelector(".button");

	public SSOPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	/**
	 * Method to load the SSOStageApplication base URL.
	 */
	
	public SSOPage getSSOApplication() throws Exception{
		try {
			driver.manage().window().maximize();
			/*Process proc = Runtime.getRuntime().exec(".\\IE_ClearCache.bat");
			proc.waitFor();*/
			driver.get(properties.getProperty("SSOStageURL"));
		}
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to launch the application using " + properties.getProperty("SSOTestURL"));
				throw (new Exception(t.getMessage()));
		}
		return this;
	}

	public SSOPage typeUserName(String testCase) throws Exception {
		try {
			getElement(userNameTextBox).clear();
			String userName = dataLoader.getTestdata("HYCSTestData", testCase,"UserID");
			getElement(userNameTextBox).sendKeys(userName.trim());
		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to type Username in to the text box");
				throw (new Exception(t.getMessage()));
		}
		return this;
	}

	public SSOPage typePassword(String testCase) throws Exception {
		try {
			getElement(passwordTextBox).clear();
			String key = dataLoader.getTestdata("HYCSTestData", testCase,"UserID");
			String decodedPwd = StringEncrypt.decryptXOR(dataLoader.getTestdata("HYCSTestData", testCase,"Password"), key);
			getElement(passwordTextBox).sendKeys(decodedPwd);
		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to type Password in to the text box");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	public SSOPage clicksignonButton() throws Exception {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("document.getElementsByClassName('button')[0].click()");
			waitTill(5000);
		} catch (Throwable t) {
			ListenerClass.setErrorMessage("Failed to click Login Button");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	public SSOPage clickSignOffButton() throws Exception {
		try {

			switchToNewWindowBasedOnUrl(properties.getProperty("SSOSignOffURL"));
			deleteAuthentication();
			getElement(signoffBtn).sendKeys(Keys.ENTER);
			acceptAlert();

		} catch (Throwable t) {
			ListenerClass.setErrorMessage("Failed to Click signoff Button");
			throw (new Exception(t.getMessage()));
		}
		return this;
	} 
	
}