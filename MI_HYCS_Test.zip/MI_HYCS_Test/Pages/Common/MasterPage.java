package Pages.Common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import SupportLibraries.DataLoader;
import SupportLibraries.DriverScript;
import SupportLibraries.ListenerClass;
import SupportLibraries.ReusableLibrary;
import SupportLibraries.ScriptHelper;

/**
 * MasterPage : Master page contains wrapper methods for all selenium actions
 * and validations All the page classes extends master page
 * 
 * @author Cognizant
 */

public class MasterPage extends ReusableLibrary {

	private int globalTimeOuts                 = 45;
	By titleContainer                          = By.className("grid-container");
	String generalTDXpathWithTextParameterised = "//td[contains(text(),'%s')]";
	By clientTitle                             = By.className("summary-wrapper");
	Actions                       action;
	protected static DataLoader  dataLoader;
	protected static String      currentTestCaseName;
	WebDriverWait                wait;

	/**
	 * Constructor to initialize the functional library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	
	public MasterPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		dataLoader = new DataLoader();
		action = new Actions(driver);
		wait=new WebDriverWait(driver, globalTimeOuts);
	}

	/**
	 * Method returns the count of elements that satisfy the locator strategy.
	 */
	
	public int getElementCount(By by) {
		int count = getElements(by).size();
		return count;
	}

	/**
	 * Method uses the 'By' class locator to find a web element after checking
	 * its visibility on web page and returns the element to the calling
	 * function The method will wait for a global time out and throws an
	 * exception if the element is not  visible
	 * 
	 * @parameter By locator
	 */
	
	public WebElement getElement(By by) throws Exception {

		WebElement element = getWebelement(by);
		return element;

	}

	/**
	 * Method uses the 'By' class locator to find a web element after checking
	 * its presence on web page and returns the element to the calling function
	 * The method will wait for a global time out and throws an exception if the
	 * element is not present 
	 * 
	 * @parameter By locator
	 */
	
	public WebElement getElementPresent(By by) {
		WebElement element = getWebelementPresent(by, globalTimeOuts);
		return element;
	}

	/**
	 * Method uses the 'By' class locator to find a list of web elements after
	 * checking their visibility on web page and returns the elements to the
	 * calling function The method will wait for a global time out and throws an
	 * exception if the elements are not visible
	 * 
	 * @parameter By locator
	 * 
	 * @return List of webElements
	 */

	public List<WebElement> getElements(By by) {
		List<WebElement> elementList = getWebelements(by, globalTimeOuts);

		return elementList;
	}

	/**
	 * Method uses the 'By' class locator to find a list of web elements after
	 * checking their presence on web page and returns the elements to the
	 * calling function The method will wait for a global time out and throws an
	 * exception if the elements are not present
	 * 
	 * @parameter By locator
	 * 
	 * @return List of webElements
	 */
	
	public List<WebElement> getElementsPresent(By by) {
		List<WebElement> elementList = getWebelementsPesent(by, globalTimeOuts);

		return elementList;
	}

	/**
	 * Method to set the name of current running test case.The current test case
	 * name is used in report generation
	 */

	public void setCurrentTestCaseName(String testName) {
		currentTestCaseName = testName;
	}

	/**
	 * Method to retrieve the page title from the title container
	 */
	
	public String getPageTitle() throws Exception {
		try {
			String pageTitle = "";

			pageTitle = getElement(titleContainer)
					.findElement(By.tagName("h1")).getText();

			return pageTitle;
		} catch (Exception E) {
			ListenerClass.setErrorMessage("Failed to retrieve title from"
					+ " Header tag inside " + titleContainer.toString());
			throw (new Exception());
		}
	}

	/**
	 * Method to retrieve the Main page title from the Dom
	 */
	
	public String getPageMainTitle() {

		String pageTitle = driver.getTitle();
		return pageTitle;
	}

	/**
	 * Method to validate if an element is visible in the dom.Retuns a boolean
	 * true if element is visible and returns a boolean false if element is not
	 * visible
	 * 
	 * @param By
	 */
	
	public boolean isElementDisplayed(By by) {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			return true;
		} catch (ElementNotVisibleException e) {
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to validate if an element is clickable in the dom.Retuns a boolean
	 * true if element is clickable and returns a boolean false if element is
	 * not clickable
	 * 
	 * @param By
	 */

	public boolean isElementClickable(WebElement we) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(we));
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method wait for a webelement to be clickable and returns that element if it s clickable
	 */

	public WebElement getElementClickable(By locator) {
		try {
			WebElement clickableElement = new WebDriverWait(driver, 60)
					.until(ExpectedConditions.elementToBeClickable(locator));
			return clickableElement;

		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Method to check a specific web element is displayed. Wait for an element to be visible for a global time out 60 Seconds
	 */
	
	public boolean isElementVisible(By by) {
		try {
			new WebDriverWait(driver, globalTimeOuts).until(ExpectedConditions
					.visibilityOfElementLocated(by));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to check a specific web element is displayed
	 */
	
	public boolean isElementVisible(WebElement webelement) {
		try{
			return webelement.isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}

	/**
	 * Method to retrieve the data from TD tag
	 */

	public String getTextFromTDTag(String tdText) {
		String text;
		text = driver
				.findElement(
						By.xpath(String.format(
								generalTDXpathWithTextParameterised, tdText)))
				.findElement((By.xpath("..")))
				.findElement(By.cssSelector("td:nth-child(2)")).getText();
		return text;
	}

	/**
	 * Method to retrieve value from dd tag using class name
	 */
	
	public String getValueFromDDTag(By className, String headerValue) throws Exception {
		String value = getElement(className)
				.findElement(
						By.xpath(String
								.format("//dt[text()='%s']", headerValue)))
				.findElement(By.xpath("..")).findElement(By.tagName("dd"))
				.getText();
		return value;
	}

	/**
	 * Method to retrieve value from dd tag using class name
	 */
	
	public boolean isDTTagWithSpecificValuePresent(By className,
			String headerValue) throws Exception {
		boolean presence = getElement(className).findElement(
				By.xpath(String.format("//dt[text()='%s']", headerValue)))
				.isDisplayed();
		return presence;
	}

	/**
	 * Method to retrieve value from dd tag using class name
	 */
	
	public String getValueFromDDTagWildCard(By className, String headerValue) throws Exception {
		String value = getElement(className)
				.findElement(
						By.xpath(String.format("//dt[contains(text(),'%s')]",
								headerValue))).findElement(By.xpath(".."))
				.findElement(By.tagName("dd")).getText();
		return value;
	}

	/**
	 * Method to retrieve the data from TD tag
	 */

	public String getTextFromLinkInTDTag(String tdText) {
		String text;
		text = driver
				.findElement(
						By.xpath(String.format(
								generalTDXpathWithTextParameterised, tdText)))
				.findElement((By.xpath(".."))).findElement(By.tagName("a"))
				.getText();
		return text;
	}

	/**
	 * Method to get new window name
	 */

	public String getNewTabTitle() {
		String oldTab = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<String>(
				driver.getWindowHandles());
		long timeout = Integer
				.valueOf(properties.getProperty("GlobalMaxTimer"));
		Date start = new Date();
		Date end = new Date();

		waitTill(10000);
		if (tabs.size() > 1) {

			tabs.remove(oldTab);
			driver.switchTo().window(tabs.get(0));
			boolean empty = driver.getTitle().length() > 5;

			while (empty == false
					& end.getTime() - start.getTime() < timeout * 1000) {

				end = new Date();
				empty = driver.getTitle().length() > 5;
			}
		}

		String title = driver.getTitle();
		driver.close();
		driver.switchTo().window(oldTab);

		return title;
	}

	/**
	 * method to switch to the old window
	 */
	
	public void switchToOldWindow() {
		String parentWindow = driver.getWindowHandle();
		driver.switchTo().window(parentWindow);
	}

	/**
	 * Method to check a web element is present(checking negative scenario)
	 */
	
	public boolean isWebElementPresent(By webelement) {

		try {

			new WebDriverWait(driver, 30).until(ExpectedConditions
					.presenceOfElementLocated(webelement));
			return true;
		} catch (ElementNotVisibleException e) {
			return false;
		}
		catch (TimeoutException e) {
			return false;
		}
	}

	/**
	 * Method to get the table header using the column number
	 */
	
	public String getTableHeader(WebElement table, int columnnumber) {
		String tableHeader = table
				.findElement(
						By.cssSelector(String.format("th:nth-child(%s)",
								columnnumber))).getText();

		return tableHeader;
	}

	/**
	 * Method to retrieve td data with table class name , row and column value
	 */
	
	public String getTDDataWithTableWebElement(WebElement table, String row,
			String column) {
		String data = table
				.findElement(By.tagName("tbody"))
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column))).getText();

		return data;
	}

	/**
	 * Method to retrieve td data with table class name , row and column value
	 */
	
	public String getTDDataWithIndex(By tableclassname, String row,
			String column) throws Exception {
		String data = getElement(tableclassname)
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column))).getText();

		return data;
	}

	/**
	 * Method to retrieve row number of data with table class name , row and
	 * column value
	 */
	
	public String getRowNumberOfSpecificDataWithIndex(By tableclassname,
			String column, String data) throws Exception {
		int iterator;
		int totalRows = getElement(tableclassname)
				.findElement(By.tagName("tbody"))
				.findElements(By.tagName("tr")).size();
		for (iterator = 2; iterator < totalRows; iterator++) {
			if (getElement(tableclassname)
					.findElement(By.tagName("tbody"))
					.findElement(
							By.cssSelector(String.format("tr:nth-child(%s)",
									iterator)))
					.findElement(
							By.cssSelector(String.format("td:nth-child(%s)",
									column))).getText().trim()
					.equalsIgnoreCase(data)) {
				break;
			}

		}
		return String.valueOf(iterator);
	}

	/**
	 * Method to retrieve td data with table class name , row and column value
	 * and tbody tag
	 */
	
	public String getTDDataWithTBodyAndIndex(By tableclassname, String row,
			String column) throws Exception {
		String data = getElement(tableclassname)
				.findElement(By.tagName("tbody"))
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column))).getText();

		return data;
	}

	/**
	 * Method to retrieve td data with table class name , row and column value
	 * and tbody tag
	 */
	
	public String getTDDataWithTBodyIDAndIndex(By tableID, String row,
			String column) throws Exception {
		String data = getElement(tableID)
				.findElement(By.tagName("tbody"))
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column))).getText();

		return data;
	}

	/**
	 * Method to retrieve the first TD from the table using table Identifier and
	 * specific data
	 */
	
	public WebElement getFirstTDFromTableContainsDataInTDInSameRow(
			By tableIdentifier, String data) throws Exception {
		WebElement we = getElement(tableIdentifier)
				.findElement(By.tagName("tbody"))
				.findElement(By.tagName("tr"))
				.findElement(
						By.xpath(String.format("//td[contains(text(),'%s')]",
								data))).findElement(By.xpath(".."))
				.findElement(By.cssSelector("td:nth-child(1)"));

		return we;

	}

	/**
	 * Method to validate the presence of a link inside a table .
	 */
	
	public boolean isLinkPresentInTDTableWithIndex(By tableclassname,
			String row, String column) throws Exception {
		boolean absence = getElement(tableclassname)
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column)))
				.findElements(By.tagName("a")).isEmpty();

		return absence;
	}

	/**
	 * Method to retrieve td data with table class name , row and column value
	 */
	
	public String getTDDataWithTableIDAndIndex(By tableclassID, String row,
			String column) throws Exception {
		String data = getElement(tableclassID)
				.findElement(By.tagName("tbody"))
				.findElement(
						By.cssSelector(String.format("tr:nth-child(%s)", row)))
				.findElement(
						By.cssSelector(String
								.format("td:nth-child(%s)", column))).getText();

		return data;
	}

	/**
	 * Method to retrieve all the values from a combo box
	 */
	
	public List<String> getAllValuesFromComboBox(By select) {
		List<WebElement> options = new ArrayList<WebElement>();
		List<String> optionsValues = new ArrayList<String>();

		options = driver.findElement(select).findElements(By.tagName("option"));
		for (WebElement option : options)
			optionsValues.add(option.getText());

		return optionsValues;

	}

	/**
	 * Method to retrieve selected value from a combo box
	 */
	
	public String getDefaultValueFromComboBox(By comboBox) throws Exception {
		WebElement select = getElement(comboBox);
		Select option = new Select(select);
		String selectedOption = option.getFirstSelectedOption().getText()
				.trim();
		return selectedOption;

	}

	/**
	 * Method to check a web element is absent
	 */
	
	public boolean isWebElementAbsent(By webelement) {
		boolean absence = driver.findElements(webelement).isEmpty();
		return absence;

	}

	/**
	 * Method execute command using java script executor
	 */
	
	public String getTextUsingJS(String javascript) {
		String value = "";

		JavascriptExecutor js = (JavascriptExecutor) driver;

		value = (String) js.executeScript(javascript);

		return value;
	}

	/**
	 * Method to wait the thread
	 */
	
	public void waitTill(long timeout) {
		try {
			Thread.sleep(timeout);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get month and year
	 */
	
	public String getMMMAndYear() {
		DateFormat df = new SimpleDateFormat("MMM/YYYY");
		Calendar cal = Calendar.getInstance();
		String monthAndYear = df.format(cal.getTime());
		return monthAndYear;

	}

	/**
	 * Method to retrieve today date
	 */
	
	public String getCurrentDate() {
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		String date = df.format(cal.getTime());
		return date;
	}

	/**
	 * Method to get month and year
	 */
	
	public String getThisYear() {
		DateFormat df = new SimpleDateFormat("yyyy");
		Calendar cal = Calendar.getInstance();
		String monthAndYear = df.format(cal.getTime());
		return monthAndYear;

	}

	/**
	 * Method to get month and year
	 */
	
	public String getPreviousYear() {
		DateFormat df = new SimpleDateFormat("yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, -1);
		String monthAndYear = df.format(cal.getTime());
		return monthAndYear;
	}

	/**
	 * Method to press down arrow
	 */
	
	public void pressDownArrow(By identifier) {
		driver.findElement(identifier).sendKeys(Keys.ARROW_DOWN);

	}

	/**
	 * Method to press down arrow
	 */
	
	public void pressDownArrow(WebElement we) {
		we.sendKeys(Keys.ARROW_DOWN);

	}

	/**
	 * Method to press Enter
	 */
	
	public void pressEnterKey(By identifier) {
		driver.findElement(identifier).sendKeys(Keys.ENTER);

	}

	/**
	 * Method to get client div (Web Element)
	 */
	
	public WebElement getClientDiv(By elementIdentifier) {
		WebElement clientDiv = driver.findElement(elementIdentifier);
		return clientDiv;
	}

	/**
	 * Method to check the presence of block in style attribute
	 */
	
	public boolean isBlockPresentInStyleAttribute(By clientIDTemp) {
		boolean presence = false, isDiplayed = false;
		long timeout = Integer
				.valueOf(properties.getProperty("GlobalMaxTimer"));
		Date start = new Date();
		Date end = new Date();
		isDiplayed = driver.findElement(clientIDTemp).getAttribute("style")
				.contains("block");

		while (isDiplayed == false
				&& end.getTime() - start.getTime() < timeout * 1000) {

			end = new Date();
			isDiplayed = driver.findElement(clientIDTemp).getAttribute("style")
					.contains("block");
		}

		if ((end.getTime() - start.getTime()) < timeout * 1000) {
			presence = true;
			waitTill(1000);
		}

		return presence;
	}

	/**
	 * Method to press the cntrl+ S to save the page
	 */
	
	public void saveUsingCntrlS() {

		try {
			String filepath = "C://Users/"+getCutrrentLoggedInUser()+"/Downloads";
			File file = new File(filepath);
			FileUtils.cleanDirectory(file);
			waitTill(10000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_S);
			waitTill(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			waitTill(3000);
		} catch (AWTException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to close all the windows except the parent window
	 */
	
	public void closeAllOtherWindows(String parent) {
		ArrayList<String> allWindowHandles = new ArrayList<String>(
				driver.getWindowHandles());

		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(parent)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}

		}
		driver.switchTo().window(parent);
	}

	/**
	 * Method to get new window name when multiple windows get open
	 */

	public String getNewTabURL() {
		waitTill(2000);
		String parent = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		Iterator<String> itr = handles.iterator();
		while (itr.hasNext()) {
			driver.switchTo().window(itr.next());
		}
		String url = driver.getCurrentUrl();
		driver.close();
		driver.switchTo().window(parent);

		return url;
	}

	/**
	 * Method to check a file is downloaded in the downloads folder
	 */
	
	public MasterPage cleanDownloadFolder() {

		String filepath = "C://Users/" + getCutrrentLoggedInUser()
		+ "/Downloads";
		File file = new File(filepath);
		try {
			FileUtils.cleanDirectory(file);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return this;
	}

	/**
	 * Method to check a file is download in the downloads folder
	 */
	
	public boolean isReportFileDownloaded(String filename) {
		long timeout = Integer
				.valueOf(properties.getProperty("GlobalMaxTimer"));
		Date start = new Date();
		Date end = new Date();
		boolean presence = false;
		String filepath = "C://Users/" + getCutrrentLoggedInUser()
		+ "/Downloads";

		File file = new File(filepath + "/" + filename);
		boolean empty = file.exists();

		while (empty == false
				& end.getTime() - start.getTime() < timeout * 2000) {

			end = new Date();
			empty = file.exists();
		}

		if (file.exists())
			presence = true;

		return presence;
	}

	/**
	 * Method to check a file is download in the downloads folder
	 */
	
	public boolean isFilePresentInDownLoadFolder() {
		long timeout = Integer
				.valueOf(properties.getProperty("GlobalMaxTimer"));
		Date start = new Date();
		Date end = new Date();
		boolean presence = false;
		File filepath = new File("C://Users/" + getCutrrentLoggedInUser()
		+ "/Downloads");

		boolean empty = filepath.list().length > 0;

		while (empty == false
				& end.getTime() - start.getTime() < timeout * 1000) {

			end = new Date();
			empty = filepath.list().length > 0;
		}

		if (filepath.list().length > 0)
			presence = true;

		return presence;
	}

	/**
	 * Method to get current user
	 */
	
	public String getCutrrentLoggedInUser() {
		return System.getProperty("user.name");
	}

	/**
	 * Method to get current url
	 */
	
	public String getPageURL() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;
	}

	/**
	 * Method to get link web element by providing the link text
	 */
	
	public WebElement getWebElementWithLinkText(String linkText) throws Exception {
		String lastFourDigits = linkText.substring(linkText.length() - 4,
				linkText.length());
		WebElement we = getElement(By.xpath("//a[contains(text(),'"
				+ lastFourDigits + "')]"));
		return we;
	}

	/**
	 * Method to return the by of link text
	 */
	
	public By getByWithLinkText(String linkText) {
		String lastFourDigits = linkText.substring(linkText.length() - 4,
				linkText.length());

		return By.xpath("//a[contains(text(),'" + lastFourDigits + "')]");
	}

	/**
	 * Method to return the by of link text
	 */
	
	public By getByWittdText(String linkText) {
		String lastFourDigits = linkText.substring(linkText.length() - 4,
				linkText.length());

		return By.xpath("//td[contains(text(),'" + lastFourDigits + "')]");
	}

	/**
	 * Method to replace characters in a string except the last four
	 */
	
	public String getStringReplacedWithX(String original) {
		StringBuilder newString = new StringBuilder(original);
		for (int loop = 0; loop < original.length() - 4; loop++)
			newString.setCharAt(loop, 'x');
		return newString.toString();

	}

	/**
	 * Method to remove dollar from a string and convert it to int
	 */
	
	public float getDollarValueInFloat(String value) {

		String[] first = value.split("\\n");
		String[] temp = first[0].split("\\$");
		if (temp[1].contains(",")) {
			temp = temp[1].split("\\,");
			temp[1] = temp[0] + temp[1];
		}
		return Float.parseFloat(temp[1].trim());
	}

	public float getDollarValueInFloatinSameLine(String value) {

		String[] temp = value.split("\\$");
		temp = temp[1].split("\\,");
		String total = "";
		for (int iter = 0; iter < temp.length; iter++) {
			if (temp[iter].contains(")")) {
				String[] valuee = temp[iter].split("\\)");
				temp[iter] = valuee[0];
			}
			total = total + temp[iter].trim();
		}
		return Float.parseFloat(total.trim());
	}

	/**
	 * Method to retrieve the column number of a text in table
	 */
	
	public String getColumnNumberOFTableHeader(By className, String header) throws Exception {
		String attribute = getElement(className).findElement(
				By.xpath(String.format("//th[contains(text(),'%s')]", header)))
				.getAttribute("class");
		String[] attributeValues = attribute.split("-");
		return attributeValues[1];
	}

	/**
	 * Method to retrieve the table containing the product number
	 */
	
	public WebElement getTableContainingProductNumber(String productNumber) throws Exception {

		WebElement we = getElement(By.linkText(productNumber)).findElement(
				By.xpath("../../../.."));
		return we;
	}

	/**
	 * Method to invoke an element which is not in visibility of the browser *
	 */
	
	public void clickUsingJavaScript(WebElement we) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", we);
	}

	/**
	 * Method to navigate back
	 */
	
	public void navigateback() {
		driver.navigate().back();
	}

	/**
	 * Method to wait for element to be present
	 */
	
	public void waitForElementPresent(By locator, int timeOuts) {
		new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.presenceOfElementLocated(locator));

	}

	/**
	 * Method to wait for element to be Visible
	 */
	
	public void waitForElementVisible(By locator, int timeOuts) {
		new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.visibilityOfElementLocated(locator));
	}

	/**
	 * Method to wait for element to be InVisible
	 */
	
	public void waitForElementInVisible(By locator, int timeOuts) {
		new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.invisibilityOfElementLocated(locator));
	}

	/**
	 * Method to wait for element to be Clickable
	 */
	
	public void waitForElementClickable(By locator, int timeOuts) {
		new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.elementToBeClickable(locator));
	}

	/**
	 * Method to wait for element to be visible and return presence
	 */
	
	public boolean isElementVisible(By locator, int timeOuts) {
		try {
			new WebDriverWait(driver, timeOuts).until(ExpectedConditions
					.visibilityOfElementLocated(locator));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Method to retrieve the page Sub title from the title container
	 */
	
	public String getPageSubTitleForClient() throws Exception {

		String pageSubTitle = getElement(By.tagName("h2")).getText();
		return pageSubTitle;
	}

	/**
	 * Method to retrieve a web element.throw an exception if the element is not
	 * present
	 * 
	 * @param locator
	 * @return
	 * @throws Exception 
	 */
	
	private WebElement getWebelement(By locator) throws Exception {
		try {
			return wait.until(ExpectedConditions
					.visibilityOfElementLocated(locator));
		} catch (NullPointerException E) {

			throw (new Exception("Failed to get the element"));
		}
	}

	/**
	 * Method to retrieve a web element
	 * 
	 * @param locator
	 * @param timeOuts
	 * @return
	 */
	
	public WebElement getWebelementPresent(By locator, int timeOuts) {
		try {
			return new WebDriverWait(driver, timeOuts).until(ExpectedConditions
					.presenceOfElementLocated(locator));
		} catch (Exception E) {
			return null;
		}
	}

	/**
	 * Method to wait for element to be Clickable
	 */
	
	public WebElement waitForWebElementClickable(By locator, int timeOuts) {
		try{
			return new WebDriverWait(driver, timeOuts).until(ExpectedConditions
					.elementToBeClickable(locator));
		}
		catch(Exception E){
			return null;
		}
	}

	/**
	 * Returns a List of webelement
	 * 
	 * @param locator
	 * @param timeOuts
	 * @return
	 */
	
	public List<WebElement> getWebelements(By locator, int timeOuts) {

		return new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.visibilityOfAllElementsLocatedBy(locator));
	}

	/**
	 * Returns a List of webelement 
	 * 
	 * @param locator
	 * @param timeOuts
	 * @return
	 */
	
	public List<WebElement> getWebelementsPesent(By locator, int timeOuts) {

		return new WebDriverWait(driver, timeOuts).until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(locator));
	}

	/**
	 * Method to scroll to a particular web element using JavaScript Executor
	 * 
	 * @param element
	 */
	
	public void scrollToElement(WebElement element) {

		String pos = element.getLocation().toString();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo" + pos, "");
	}

	/**
	 * method to validate whether a particular option is present inside a drop down
	 * @param locator
	 * @param option
	 * @return
	 */
	
	public boolean isOptionAvailableInDropDown(By locator, String option) {
		boolean flag = false;

		try {

			Select dropDown = new Select(getElement(locator));
			List<WebElement> list = dropDown.getOptions();
			for (WebElement opt : list) {
				if (opt.getText().equalsIgnoreCase(option))
					flag = true;
			}
			return flag;
		} catch (Exception e) {
			return false;
		}
	} 

	/**
	 * Method to select from Dropdown
	 * 
	 * @param locator
	 * @param value
	 * @throws Exception 
	 */
	
	public void selectFromDropdown(By locator, String value) throws Exception {
		Select dropDown = new Select(getElement(locator));
		dropDown.selectByVisibleText(value);
	}

	/**
	 * Method to move to element using actions in CSS page
	 */

	public void moveToElement(By locater) throws Exception{
		WebElement target=getElement(locater);
		action.moveToElement(target).perform();
	}

	/**
	 * Method to move to element and click using actions
	 */

	public MasterPage moveToElementAndClick(By hoverElement,By elementTobeClicked) throws Exception{

		action.moveToElement(getElement(hoverElement)).build().perform();
		getElement(elementTobeClicked);
		return this;
	}

	/**
	 * method to Navigate to a particular Url
	 */
	
	public void navigateToUrl(String url) {
		driver.get(url);
	}

	/**
	 * Method to check a specific web element is displayed. Wait for an element to be visible for a global time out 60 Seconds
	 */
	
	public boolean isElementVisibleWithOutTimeOut(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * Method to scroll using Java Robot class
	 * @param limit
	 */
	
	public void scrollUsingRobot(int limit){
		Robot robot;
		try {
			robot = new Robot();

			robot.mouseWheel(limit);
			waitTill(2000);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the web element if there are any duplicates
	 */
	
	public WebElement getVisiblelementFromDuplicateSet(By locator) {
		WebElement visibleElement = null;
		try {
			List<WebElement> elementList = getElementsPresent(locator);
			for (WebElement element : elementList) {
				if (element.isDisplayed()) {
					visibleElement = element;
					break;
				}

			}
		} catch (Exception e) {
			return null;
		}
		return visibleElement;
	}

	/**
	 * Method to Switch Window based on url
	 */

	public void switchToNewWindowBasedOnPageTitle(String url) throws Exception
	{
		waitTill(5000);
		for (String windowHandle : driver.getWindowHandles()) {
			driver.switchTo().window(windowHandle);
			waitTill(5000);
			if (driver.getCurrentUrl().contains(url)) {
				break;
			}
		}
	} 
	
	/**
	 * Method to clear Authentication Cache
	 */
	
	public void deleteAuthentication() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:document.execCommand('ClearAuthenticationCache')");
		
	} 
	
	/**
	 * Method to handle Alert
	 */
	
	public boolean isAlertPresent() {

		try {
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		}
		catch(Throwable t) {
			return false;
		}
	}

	public void acceptAlert() {
		if(isAlertPresent()) {
			driver.switchTo().alert().accept();
		}
	}

	/**
	 * Method to Switch Window based on url
	 */
	
	public void switchToNewWindowBasedOnUrl(String url) {
		for (String windowHandle : driver.getWindowHandles()) {
			driver.switchTo().window(windowHandle);
			if (driver.getTitle().contains(url)) {
				break;
			}
		}
	}

}