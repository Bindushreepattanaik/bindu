package TestScripts.TechUpgrade.MI.HYCS;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Common.SSOPage;
import Pages.MI.HYCS.HYCSCSSPage;
import Pages.MI.HYCS.HYCSHomePage;
import SupportLibraries.BaseTest;
import SupportLibraries.ListenerClass;
import SupportLibraries.Log;

public class HYCSTest extends BaseTest
{
	Log.info("This is logging 0");
	@BeforeClass
	public void intialize()
	{
		Log.info("This is logging 1");
		ssoPage			= new SSOPage(driverScript.getBaseTest().getScriptHelper());
		Log.info("This is logging 2");
		HYCSCssPage		= new HYCSCSSPage(driverScript.getBaseTest().getScriptHelper());
		Log.info('This is logging 3');
		HYCSHomePage	= new HYCSHomePage(driverScript.getBaseTest().getScriptHelper());
		Log.info('This is logging 4');
		Log.error(message);
	}
	
	/**
	 * SSO_login : 'Logging into the SSO'
	 */
	
	@Test
	public void SSO_login() {
		try {
			
			ssoPage.getSSOApplication();
			ssoPage.typeUserName("TC_SSO_Login");
			ssoPage.typePassword("TC_SSO_Login");
			ssoPage.clicksignonButton();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_launch : 'Launching the Application'
	 */
	
	@Test( dependsOnMethods = {"SSO_login"} )
	public void TC_HYCS_launch() {
		try {
			HYCSCssPage.getHYCSApplication();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_01_homePage : 'Validation of Home Page Fields'
	 */
	
	//@Test( dependsOnMethods = {"TC_HYCS_launch"} )
	public void TC_HYCS_01_homePage() {
		try {
			HYCSHomePage.verifyHYCSHomePage("TC_HYCS_01");
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_HYCS_02_fundamentalsLinkPage : 'Validation of Fundamentals Link Page Fields'
	 */
	
	@Test( dependsOnMethods = {"TC_HYCS_01_homePage"} )
	public void TC_HYCS_02_fundamentalsLinkPage() {
		try {
			HYCSHomePage.verifyFundamentalsPage("TC_HYCS_02");
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 *  SSO_signOff : 'Validate user able to Sign Off'
	 */
	
	@Test(dependsOnMethods = { "TC_HYCS_02_fundamentalsLinkPage" })
	public void SSO_signOff() {
		try {
			ssoPage.clickSignOffButton();
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
}